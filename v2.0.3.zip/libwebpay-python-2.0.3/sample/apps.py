"""
@author     Allware Ltda. (http://www.allware.cl)
@copyright  2016 Transbank S.A. (http://www.tranbank.cl)
@date       Jan 2015
@license    GNU LGPL
@version    2.0.1
"""

from __future__ import unicode_literals

from django.apps import AppConfig

class SampleConfig(AppConfig):
    name = 'sample'
