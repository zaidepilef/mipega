class SignatureVerificationFailed(Exception):
    pass
